# ZELORA — première page d'accueil

Ce dossier contient une première maquette statique de la marketplace ZELORA.

## Fichiers
- `index.html` : structure de la page.
- `style.css` : design responsive blanc et rose pâle.
- `app.js` : recherche, filtres par catégorie et panier de démonstration.

## Important
Les huit articles affichés sont des exemples fictifs. Les prix sont fictifs. Le panier ne passe aucune commande et aucun paiement n'est traité. Il n'y a pas encore de base de données, d'espace vendeur connecté, de compte client ni de système de livraison.

Avant d'ouvrir la marketplace au public :
1. Remplacer les exemples par des produits réellement proposés et confirmés par les vendeurs.
2. Ajouter une base de données et une authentification sécurisée.
3. Définir les conditions vendeurs/clients et le traitement des commandes.
4. Faire vérifier les démarches commerciales, les paiements et la protection des données par un adulte de confiance et des professionnels compétents.

## Publier avec GitHub Pages
1. Crée un dépôt GitHub indépendant nommé `zelora`.
2. Décompresse ce dossier.
3. Ajoute `index.html`, `style.css`, `app.js` et `README.md` à la racine du dépôt (pas dans un sous-dossier).
4. Fais `Commit changes`.
5. Dans le dépôt, ouvre **Settings → Pages**.
6. Dans **Build and deployment**, choisis **Deploy from a branch**, branche `main`, dossier `/ (root)`, puis **Save**.
7. Attends la fin du déploiement. GitHub affichera l'adresse publique du site dans la section Pages.

Le nom de domaine personnalisé pourra être envisagé plus tard. Ne publie pas de numéro privé ni de données personnelles dans les fichiers.


Mise à jour de l'identité visuelle : le nom ZELORA utilise désormais une typographie élégante Cormorant Garamond, avec un Z rose poudré et blanc. La palette rose poudré/blanc est conservée.
