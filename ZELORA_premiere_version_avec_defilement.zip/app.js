const products = [
  {id:1,name:"Ensemble décontracté",category:"Mode",price:12500,symbol:"♧",tone:"pink"},
  {id:2,name:"Sneakers urbaines",category:"Chaussures",price:18000,symbol:"◒",tone:"cream"},
  {id:3,name:"Sac du quotidien",category:"Accessoires",price:9500,symbol:"▱",tone:"pink"},
  {id:4,name:"Ensemble de sport",category:"Sport",price:15000,symbol:"⚽",tone:"lilac"},
  {id:5,name:"Coffret beauté",category:"Beauté",price:8000,symbol:"❀",tone:"cream"},
  {id:6,name:"Décoration maison",category:"Maison",price:11000,symbol:"⌂",tone:"pink"},
  {id:7,name:"Casquette classique",category:"Accessoires",price:5000,symbol:"♧",tone:"lilac"},
  {id:8,name:"Paire de chaussures",category:"Chaussures",price:14000,symbol:"◒",tone:"cream"}
];
let selectedCategory = "Tout";
let cart = [];
const money = n => new Intl.NumberFormat("fr-FR").format(n) + " FCFA";
const productGrid = document.getElementById("productGrid");
const emptyState = document.getElementById("emptyState");
const cartDrawer = document.getElementById("cartDrawer");
const backdrop = document.getElementById("drawerBackdrop");
const toast = document.getElementById("toast");

function showToast(message){
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(()=>toast.classList.remove("show"),2200);
}
function renderProducts(){
  const q = document.getElementById("searchInput").value.trim().toLowerCase();
  const filtered = products.filter(p => (selectedCategory==="Tout" || p.category===selectedCategory) && (p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q)));
  productGrid.innerHTML = filtered.map(p=>`
    <article class="product-card">
      <div class="product-visual"><span class="visual-symbol">${p.symbol}</span><span class="visual-label">EXEMPLE ZELORA</span></div>
      <div class="product-info"><span class="product-category">${p.category}</span><h3>${p.name}</h3>
        <div class="product-bottom"><span class="product-price">${money(p.price)}</span><button class="add-button" data-add="${p.id}">Ajouter +</button></div>
      </div>
    </article>`).join("");
  emptyState.hidden = filtered.length !== 0;
}
function addToCart(id){
  const existing = cart.find(x=>x.id===id);
  if(existing) existing.qty++;
  else cart.push({id,qty:1});
  renderCart();
  showToast("Article ajouté au panier de démonstration.");
}
function changeQty(id,delta){
  const item = cart.find(x=>x.id===id);
  if(!item) return;
  item.qty += delta;
  if(item.qty<=0) cart = cart.filter(x=>x.id!==id);
  renderCart();
}
function renderCart(){
  const count = cart.reduce((sum,x)=>sum+x.qty,0);
  document.getElementById("cartCount").textContent = count;
  document.getElementById("cartItems").innerHTML = cart.length ? cart.map(item=>{
    const p=products.find(x=>x.id===item.id);
    return `<div class="cart-row"><div class="cart-thumb">${p.symbol}</div><div class="cart-row-info"><b>${p.name}</b><small>${money(p.price)}</small></div><div class="quantity-controls"><button data-qty="${p.id}" data-delta="-1" aria-label="Retirer un article">−</button><span>${item.qty}</span><button data-qty="${p.id}" data-delta="1" aria-label="Ajouter un article">+</button></div></div>`;
  }).join("") : `<div class="cart-empty">Votre panier de démonstration est vide.</div>`;
  const total=cart.reduce((sum,item)=>sum+products.find(p=>p.id===item.id).price*item.qty,0);
  document.getElementById("cartTotal").textContent=money(total);
}
function openCart(){cartDrawer.classList.add("open");cartDrawer.setAttribute("aria-hidden","false");backdrop.hidden=false;document.body.style.overflow="hidden";}
function closeCart(){cartDrawer.classList.remove("open");cartDrawer.setAttribute("aria-hidden","true");backdrop.hidden=true;document.body.style.overflow="";}
document.getElementById("categoryGrid").addEventListener("click",e=>{
  const button=e.target.closest("[data-category]");
  if(!button)return;
  selectedCategory=button.dataset.category;
  document.querySelectorAll(".category-tile").forEach(el=>el.classList.toggle("active",el===button));
  renderProducts();
  document.getElementById("produits").scrollIntoView({behavior:"smooth"});
});
productGrid.addEventListener("click",e=>{
  const button=e.target.closest("[data-add]");
  if(button)addToCart(Number(button.dataset.add));
});
document.getElementById("searchInput").addEventListener("input",renderProducts);
document.getElementById("openCart").addEventListener("click",openCart);
document.getElementById("closeCart").addEventListener("click",closeCart);
backdrop.addEventListener("click",closeCart);
document.getElementById("cartItems").addEventListener("click",e=>{
  const button=e.target.closest("[data-qty]");
  if(button)changeQty(Number(button.dataset.qty),Number(button.dataset.delta));
});
document.getElementById("demoCheckout").addEventListener("click",()=>{
  if(!cart.length){showToast("Ajoutez d'abord un article exemple.");return;}
  showToast("Démonstration uniquement : aucune commande réelle n'est envoyée.");
});
document.getElementById("year").textContent=new Date().getFullYear();
renderProducts();renderCart();


// Défilement du cadre d'articles avec les flèches (et glissement tactile sur mobile).
const carousel = document.getElementById("productGrid");
document.getElementById("carouselPrev").addEventListener("click",()=>{
  carousel.scrollBy({left:-carousel.clientWidth*0.8,behavior:"smooth"});
});
document.getElementById("carouselNext").addEventListener("click",()=>{
  carousel.scrollBy({left:carousel.clientWidth*0.8,behavior:"smooth"});
});
